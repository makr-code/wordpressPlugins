<?php
/**
 * ThemisDB Theme v3 - Minimal Generic Functions
 *
 * @package ThemisDB_V3
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'THEMISDB_V3_VERSION', '3.1.0' );

add_action( 'after_setup_theme', 'themisdb_v3_setup' );
function themisdb_v3_setup() {
    load_theme_textdomain( 'themisdb-v3', get_template_directory() . '/languages' );

    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    add_theme_support( 'block-templates' );
    add_theme_support( 'editor-styles' );

    add_theme_support(
        'custom-logo',
        array(
            'height'      => 96,
            'width'       => 320,
            'flex-height' => true,
            'flex-width'  => true,
        )
    );

    add_editor_style( 'style.css' );

    register_nav_menus(
        array(
            'primary' => __( 'Primary Navigation', 'themisdb-v3' ),
            'footer'  => __( 'Footer Navigation', 'themisdb-v3' ),
        )
    );
}

add_action( 'init', 'themisdb_v3_register_shortcodes', 15 );
/**
 * Register frontend shortcodes used by template parts.
 */
function themisdb_v3_register_shortcodes() {
    add_shortcode( 'themisdb_v3_breadcrumbs', 'themisdb_v3_render_breadcrumbs_shortcode' );
}

/**
 * Render a context-aware breadcrumb trail.
 *
 * @return string
 */
function themisdb_v3_render_breadcrumbs_shortcode() {
    $items = array(
        array(
            'label' => __( 'Home', 'themisdb-v3' ),
            'url'   => home_url( '/' ),
        ),
    );

    $current_label = '';

    if ( is_singular() ) {
        $post = get_queried_object();
        if ( $post instanceof WP_Post ) {
            if ( 'page' === $post->post_type ) {
                $ancestors = array_reverse( get_post_ancestors( $post ) );
                foreach ( $ancestors as $ancestor_id ) {
                    $items[] = array(
                        'label' => get_the_title( $ancestor_id ),
                        'url'   => get_permalink( $ancestor_id ),
                    );
                }
            } else {
                $post_type_object = get_post_type_object( $post->post_type );
                if ( $post_type_object && ! empty( $post_type_object->has_archive ) ) {
                    $archive_link = get_post_type_archive_link( $post->post_type );
                    if ( $archive_link ) {
                        $items[] = array(
                            'label' => (string) $post_type_object->labels->name,
                            'url'   => $archive_link,
                        );
                    }
                }
            }

            $current_label = get_the_title( $post );
        }
    } elseif ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term instanceof WP_Term ) {
            if ( 'category' !== $term->taxonomy && 'post_tag' !== $term->taxonomy ) {
                $taxonomy = get_taxonomy( $term->taxonomy );
                if ( $taxonomy && ! empty( $taxonomy->labels->name ) ) {
                    $items[] = array(
                        'label' => (string) $taxonomy->labels->name,
                        'url'   => '',
                    );
                }
            }
            $current_label = single_term_title( '', false );
        }
    } elseif ( is_post_type_archive() ) {
        $current_label = post_type_archive_title( '', false );
    } elseif ( is_search() ) {
        $current_label = sprintf( __( 'Search: %s', 'themisdb-v3' ), get_search_query() );
    } elseif ( is_404() ) {
        $current_label = __( 'Not Found', 'themisdb-v3' );
    } else {
        $current_label = wp_get_document_title();
    }

    $current_label = wp_strip_all_tags( (string) $current_label );
    if ( '' === trim( $current_label ) ) {
        $current_label = __( 'Current Page', 'themisdb-v3' );
    }

    $html = '<nav class="tv3-breadcrumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'themisdb-v3' ) . '">';
    $html .= '<ol class="tv3-breadcrumbs-list" itemscope itemtype="https://schema.org/BreadcrumbList">';

    $position = 1;
    foreach ( $items as $item ) {
        $label = isset( $item['label'] ) ? trim( (string) $item['label'] ) : '';
        $url   = isset( $item['url'] ) ? (string) $item['url'] : '';
        if ( '' === $label ) {
            continue;
        }

        $html .= '<li class="tv3-breadcrumbs-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
        if ( '' !== $url ) {
            $html .= '<a href="' . esc_url( $url ) . '" itemprop="item"><span itemprop="name">' . esc_html( $label ) . '</span></a>';
        } else {
            $html .= '<span itemprop="name">' . esc_html( $label ) . '</span>';
        }
        $html .= '<meta itemprop="position" content="' . (int) $position . '" />';
        $html .= '</li>';
        $position++;
    }

    $html .= '<li class="tv3-breadcrumbs-item is-current" aria-current="page" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
    $html .= '<span itemprop="name">' . esc_html( $current_label ) . '</span>';
    $html .= '<meta itemprop="position" content="' . (int) $position . '" />';
    $html .= '</li>';
    $html .= '</ol></nav>';

    return $html;
}

add_action( 'init', 'themisdb_v3_sync_navigation_template_parts', 20 );
/**
 * Keep block navigation refs in header/footer aligned with configured menu locations.
 */
function themisdb_v3_sync_navigation_template_parts() {
    if ( wp_doing_ajax() || wp_is_json_request() ) {
        return;
    }

    $signature      = themisdb_v3_get_navigation_sync_signature();
    $option_name    = 'themisdb_v3_nav_sync_signature';
    $last_signature = (string) get_option( $option_name, '' );

    if ( $signature === $last_signature ) {
        return;
    }

    if ( themisdb_v3_apply_navigation_template_part_sync() ) {
        update_option( $option_name, $signature, false );
    }
}

/**
 * Build a compact signature so sync only runs when menu assignments/content changed.
 *
 * @return string
 */
function themisdb_v3_get_navigation_sync_signature() {
    $locations = (array) get_theme_mod( 'nav_menu_locations', array() );
    $parts     = array( get_stylesheet() );

    foreach ( array( 'primary', 'footer' ) as $location ) {
        $term_id = isset( $locations[ $location ] ) ? (int) $locations[ $location ] : 0;
        $parts[] = $location . ':' . $term_id;

        if ( $term_id <= 0 ) {
            continue;
        }

        $items = wp_get_nav_menu_items( $term_id, array( 'update_post_term_cache' => false ) );
        if ( ! is_array( $items ) ) {
            continue;
        }

        foreach ( $items as $item ) {
            $parts[] = implode(
                ':',
                array(
                    (string) $item->db_id,
                    (string) (int) $item->menu_order,
                    (string) $item->object,
                    (string) $item->object_id,
                    (string) $item->url,
                )
            );
        }
    }

    return md5( implode( '|', $parts ) );
}

/**
 * Sync classic menu locations into block navigation refs used by template parts.
 *
 * @return bool
 */
function themisdb_v3_apply_navigation_template_part_sync() {
    $primary_navigation_id = themisdb_v3_ensure_navigation_post_from_location( 'primary', 'TV3 Primary Navigation' );
    $footer_navigation_id  = themisdb_v3_ensure_navigation_post_from_location( 'footer', 'TV3 Footer Navigation' );

    if ( $primary_navigation_id <= 0 && $footer_navigation_id <= 0 ) {
        return false;
    }

    if ( $primary_navigation_id > 0 ) {
        themisdb_v3_sync_template_part_navigation_ref( 'header', $primary_navigation_id, false );
    }

    if ( $footer_navigation_id > 0 ) {
        themisdb_v3_sync_template_part_navigation_ref( 'footer', $footer_navigation_id, true );
    }

    return true;
}

/**
 * Create or update a wp_navigation post from a classic location menu.
 *
 * @param string $location Location slug.
 * @param string $title    Navigation post title.
 * @return int
 */
function themisdb_v3_ensure_navigation_post_from_location( $location, $title ) {
    if ( ! class_exists( 'WP_Classic_To_Block_Menu_Converter' ) ) {
        $converter_file = ABSPATH . WPINC . '/class-wp-classic-to-block-menu-converter.php';
        if ( file_exists( $converter_file ) ) {
            require_once $converter_file;
        }
    }

    if ( ! class_exists( 'WP_Classic_To_Block_Menu_Converter' ) ) {
        return 0;
    }

    $locations = (array) get_theme_mod( 'nav_menu_locations', array() );
    $term_id   = isset( $locations[ $location ] ) ? (int) $locations[ $location ] : 0;
    if ( $term_id <= 0 ) {
        return 0;
    }

    $menu = wp_get_nav_menu_object( $term_id );
    if ( ! $menu ) {
        return 0;
    }

    $content = WP_Classic_To_Block_Menu_Converter::convert( $menu );
    if ( is_wp_error( $content ) ) {
        return 0;
    }

    $option_name  = 'themisdb_v3_nav_post_id_' . sanitize_key( $location );
    $existing_id  = (int) get_option( $option_name, 0 );
    $existing_nav = $existing_id > 0 ? get_post( $existing_id ) : null;

    if ( ! $existing_nav || 'wp_navigation' !== $existing_nav->post_type ) {
        $found = get_posts(
            array(
                'post_type'      => 'wp_navigation',
                'post_status'    => array( 'publish', 'draft' ),
                'title'          => $title,
                'numberposts'    => 1,
                'fields'         => 'ids',
                'suppress_filters' => false,
            )
        );
        $existing_id = ! empty( $found ) ? (int) $found[0] : 0;
    }

    $postarr = array(
        'post_type'    => 'wp_navigation',
        'post_status'  => 'publish',
        'post_title'   => $title,
        'post_content' => (string) $content,
    );

    if ( $existing_id > 0 ) {
        $postarr['ID'] = $existing_id;
        $result        = wp_update_post( $postarr, true );
    } else {
        $result = wp_insert_post( $postarr, true );
    }

    if ( is_wp_error( $result ) || $result <= 0 ) {
        return 0;
    }

    update_option( $option_name, (int) $result, false );

    return (int) $result;
}

/**
 * Find a theme template part post by slug.
 *
 * @param string $slug Template part slug.
 * @return WP_Post|null
 */
function themisdb_v3_get_theme_template_part_post( $slug ) {
    $query = new WP_Query(
        array(
            'post_type'      => 'wp_template_part',
            'post_status'    => array( 'publish', 'draft' ),
            'name'           => sanitize_title( $slug ),
            'posts_per_page' => 1,
            'tax_query'      => array(
                array(
                    'taxonomy' => 'wp_theme',
                    'field'    => 'name',
                    'terms'    => get_stylesheet(),
                ),
            ),
        )
    );

    return ! empty( $query->posts ) ? $query->posts[0] : null;
}

/**
 * Bind navigation block refs for a template part.
 *
 * @param string $slug         Template part slug.
 * @param int    $ref_id       wp_navigation post ID.
 * @param bool   $apply_to_all Whether to bind all navigation blocks.
 */
function themisdb_v3_sync_template_part_navigation_ref( $slug, $ref_id, $apply_to_all ) {
    $template_part = themisdb_v3_get_theme_template_part_post( $slug );
    if ( ! $template_part || empty( $template_part->post_content ) ) {
        return;
    }

    $blocks      = parse_blocks( $template_part->post_content );
    $bound_count = 0;

    themisdb_v3_bind_navigation_ref_to_blocks( $blocks, (int) $ref_id, (bool) $apply_to_all, $bound_count );

    if ( $bound_count <= 0 ) {
        return;
    }

    $serialized = serialize_blocks( $blocks );
    if ( $serialized === $template_part->post_content ) {
        return;
    }

    wp_update_post(
        array(
            'ID'           => (int) $template_part->ID,
            'post_content' => $serialized,
        )
    );
}

/**
 * Recursively attach a wp_navigation reference to core/navigation blocks.
 *
 * @param array<int,array<string,mixed>> $blocks      Parsed blocks.
 * @param int                            $ref_id      wp_navigation post ID.
 * @param bool                           $apply_to_all Whether to bind all matches.
 * @param int                            $bound_count Number of updated blocks.
 */
function themisdb_v3_bind_navigation_ref_to_blocks( array &$blocks, $ref_id, $apply_to_all, &$bound_count ) {
    foreach ( $blocks as &$block ) {
        if ( isset( $block['blockName'] ) && 'core/navigation' === $block['blockName'] ) {
            if ( $apply_to_all || 0 === $bound_count ) {
                if ( ! isset( $block['attrs'] ) || ! is_array( $block['attrs'] ) ) {
                    $block['attrs'] = array();
                }

                $block['attrs']['ref'] = (int) $ref_id;

                // Ensure frontend uses referenced navigation content consistently.
                $block['innerBlocks']  = array();
                $block['innerHTML']    = '';
                $block['innerContent'] = array();

                $bound_count++;
            }
        }

        if ( ! empty( $block['innerBlocks'] ) ) {
            themisdb_v3_bind_navigation_ref_to_blocks( $block['innerBlocks'], $ref_id, $apply_to_all, $bound_count );
        }
    }
}

add_filter( 'render_block_data', 'themisdb_v3_bind_navigation_ref_for_file_parts', 10, 2 );
/**
 * Ensure file-based navigation blocks resolve to configured menus without DB part overrides.
 *
 * @param array<string,mixed> $parsed_block Parsed block data.
 * @param array<string,mixed> $source_block Source block data.
 * @return array<string,mixed>
 */
function themisdb_v3_bind_navigation_ref_for_file_parts( $parsed_block, $source_block ) {
    if ( empty( $parsed_block['blockName'] ) || 'core/navigation' !== $parsed_block['blockName'] ) {
        return $parsed_block;
    }

    if ( ! empty( $parsed_block['attrs']['ref'] ) ) {
        return $parsed_block;
    }

    $location = isset( $parsed_block['attrs']['__unstableLocation'] ) ? (string) $parsed_block['attrs']['__unstableLocation'] : '';
    if ( ! in_array( $location, array( 'primary', 'footer' ), true ) ) {
        return $parsed_block;
    }

    $ref = themisdb_v3_get_navigation_post_id_for_location( $location );
    if ( $ref <= 0 ) {
        return $parsed_block;
    }

    if ( ! isset( $parsed_block['attrs'] ) || ! is_array( $parsed_block['attrs'] ) ) {
        $parsed_block['attrs'] = array();
    }

    $parsed_block['attrs']['ref'] = (int) $ref;

    return $parsed_block;
}

/**
 * Get an existing navigation post ID for a location without mutating content at render time.
 *
 * @param string $location Location slug.
 * @return int
 */
function themisdb_v3_get_navigation_post_id_for_location( $location ) {
    $option_name = 'themisdb_v3_nav_post_id_' . sanitize_key( $location );
    $post_id     = (int) get_option( $option_name, 0 );

    if ( $post_id > 0 ) {
        $post = get_post( $post_id );
        if ( $post && 'wp_navigation' === $post->post_type ) {
            return $post_id;
        }
    }

    $title = 'primary' === $location ? 'TV3 Primary Navigation' : 'TV3 Footer Navigation';
    $found = get_posts(
        array(
            'post_type'      => 'wp_navigation',
            'post_status'    => array( 'publish', 'draft' ),
            'title'          => $title,
            'numberposts'    => 1,
            'fields'         => 'ids',
            'suppress_filters' => false,
        )
    );

    return ! empty( $found ) ? (int) $found[0] : 0;
}

add_filter( 'render_block', 'themisdb_v3_rewrite_root_relative_links', 20, 2 );
/**
 * Rewrite root-relative links to proper site URLs for subdirectory installs.
 *
 * @param string              $block_content Rendered block HTML.
 * @param array<string,mixed> $block         Parsed block.
 * @return string
 */
function themisdb_v3_rewrite_root_relative_links( $block_content, $block ) {
    if ( is_admin() || '' === $block_content || false === strpos( $block_content, 'href="/' ) ) {
        return $block_content;
    }

    return (string) preg_replace_callback(
        '/href="\/(?!\/)([^"#]*)"/',
        static function ( $matches ) {
            $path = isset( $matches[1] ) ? (string) $matches[1] : '';
            $url  = '' === $path ? home_url( '/' ) : home_url( '/' . ltrim( $path, '/' ) );
            return 'href="' . esc_url( $url ) . '"';
        },
        $block_content
    );
}

add_action( 'wp_enqueue_scripts', 'themisdb_v3_enqueue_assets' );
function themisdb_v3_enqueue_assets() {
    wp_enqueue_style( 'themisdb-v3-style', get_stylesheet_uri(), array(), THEMISDB_V3_VERSION );
    wp_register_script(
        'themisdb-v3-mixed-cards',
        get_template_directory_uri() . '/assets/js/mixed-cards.js',
        array(),
        THEMISDB_V3_VERSION,
        true
    );
}

add_action( 'wp_body_open', 'themisdb_v3_render_skip_link', 5 );
/**
 * Render a global skip link for keyboard and assistive technology users.
 */
function themisdb_v3_render_skip_link() {
    echo '<a class="tv3-skip-link" href="#wp--skip-link--target">' . esc_html__( 'Zum Inhalt springen', 'themisdb-v3' ) . '</a>';
}

add_action( 'wp_footer', 'themisdb_v3_print_skip_link_target_fallback', 99 );
/**
 * Ensure a skip-link target exists even when customized templates omit the ID.
 */
function themisdb_v3_print_skip_link_target_fallback() {
    ?>
    <script>
    (function(){
        var main = document.querySelector('main');
        if(!main){
            return;
        }
        if(!main.id){
            main.id = 'wp--skip-link--target';
        }
        if(!main.hasAttribute('tabindex')){
            main.setAttribute('tabindex', '-1');
        }
    })();
    </script>
    <?php
}

add_action( 'init', 'themisdb_v3_register_content_object_post_types', 5 );
/**
 * Register future-ready content object types when they do not already exist.
 */
function themisdb_v3_register_content_object_post_types() {
    $definitions = array(
        'video'      => __( 'Videos', 'themisdb-v3' ),
        'screencast' => __( 'Screencasts', 'themisdb-v3' ),
        'tutorial'   => __( 'Tutorials', 'themisdb-v3' ),
    );

    foreach ( $definitions as $slug => $label ) {
        if ( post_type_exists( $slug ) ) {
            continue;
        }

        register_post_type(
            $slug,
            array(
                'label'           => $label,
                'public'          => true,
                'show_in_rest'    => true,
                'menu_position'   => 22,
                'has_archive'     => true,
                'rewrite'         => array( 'slug' => $slug ),
                'supports'        => array( 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions', 'custom-fields' ),
                'show_in_nav_menus' => true,
            )
        );
    }
}

/**
 * Get supported post types for mixed content cards.
 *
 * @return array<int,string>
 */
function themisdb_v3_get_supported_content_post_types() {
    $post_types = array( 'post', 'page' );

    $object_candidates = array(
        'pod_episode',
        'video',
        'pod_video',
        'screencast',
        'tutorial',
    );

    foreach ( $object_candidates as $candidate ) {
        if ( post_type_exists( $candidate ) ) {
            $post_types[] = $candidate;
        }
    }

    $post_types = array_values( array_unique( $post_types ) );

    /**
     * Filter supported content types for mixed cards.
     *
     * @param array<int,string> $post_types List of post types.
     */
    return (array) apply_filters( 'themisdb_v3_mixed_post_types', $post_types );
}

/**
 * Get a human-readable label for a content type.
 *
 * @param string $post_type Post type slug.
 * @return string
 */
function themisdb_v3_get_content_type_label( $post_type ) {
    $post_type = (string) $post_type;

    if ( 'pod_episode' === $post_type ) {
        return __( 'Podcast', 'themisdb-v3' );
    }

    if ( 'pod_video' === $post_type ) {
        return __( 'Video', 'themisdb-v3' );
    }

    $object = get_post_type_object( $post_type );
    if ( $object && ! empty( $object->labels->singular_name ) ) {
        return (string) $object->labels->singular_name;
    }

    return ucfirst( str_replace( array( '-', '_' ), ' ', $post_type ) );
}

/**
 * Get supported object-only content types.
 *
 * @return array<int,string>
 */
function themisdb_v3_get_supported_object_post_types() {
    return array_values(
        array_filter(
            themisdb_v3_get_supported_content_post_types(),
            static function ( $type ) {
                return themisdb_v3_is_object_content_type( (string) $type );
            }
        )
    );
}

add_action( 'wp_ajax_themisdb_v3_search_relationship_targets', 'themisdb_v3_ajax_search_relationship_targets' );
/**
 * Search relationship targets by title for the editor metabox.
 */
function themisdb_v3_ajax_search_relationship_targets() {
    if ( ! current_user_can( 'edit_posts' ) ) {
        wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
    }

    $nonce = isset( $_GET['_ajax_nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_ajax_nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'themisdb_v3_relationship_search' ) ) {
        wp_send_json_error( array( 'message' => 'invalid_nonce' ), 403 );
    }

    $mode = isset( $_GET['mode'] ) ? sanitize_key( wp_unslash( $_GET['mode'] ) ) : 'object';
    $term = isset( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';

    if ( strlen( $term ) < 2 ) {
        wp_send_json_success( array() );
    }

    $post_types = 'post' === $mode ? array( 'post', 'page' ) : themisdb_v3_get_supported_object_post_types();
    if ( empty( $post_types ) ) {
        wp_send_json_success( array() );
    }

    $query = new WP_Query(
        array(
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            'posts_per_page'      => 10,
            's'                   => $term,
            'orderby'             => 'date',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
        )
    );

    $items = array();
    foreach ( $query->posts as $item ) {
        $items[] = array(
            'id'    => (int) $item->ID,
            'title' => get_the_title( $item->ID ),
            'type'  => (string) $item->post_type,
            'label' => themisdb_v3_get_content_type_label( (string) $item->post_type ),
        );
    }

    wp_send_json_success( $items );
}

add_action( 'init', 'themisdb_v3_register_relationship_meta' );
/**
 * Register generic relationship metadata for content linking.
 */
function themisdb_v3_register_relationship_meta() {
    $types = themisdb_v3_get_supported_content_post_types();

    foreach ( $types as $type ) {
        register_post_meta(
            $type,
            'related_object_ids',
            array(
                'type'              => 'array',
                'single'            => true,
                'show_in_rest'      => array(
                    'schema' => array(
                        'type'  => 'array',
                        'items' => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
                'sanitize_callback' => 'themisdb_v3_sanitize_id_list_meta',
                'auth_callback'     => static function () {
                    return current_user_can( 'edit_posts' );
                },
            )
        );

        register_post_meta(
            $type,
            'related_post_ids',
            array(
                'type'              => 'array',
                'single'            => true,
                'show_in_rest'      => array(
                    'schema' => array(
                        'type'  => 'array',
                        'items' => array(
                            'type' => 'integer',
                        ),
                    ),
                ),
                'sanitize_callback' => 'themisdb_v3_sanitize_id_list_meta',
                'auth_callback'     => static function () {
                    return current_user_can( 'edit_posts' );
                },
            )
        );

        register_post_meta(
            $type,
            'content_object_type',
            array(
                'type'              => 'string',
                'single'            => true,
                'show_in_rest'      => true,
                'sanitize_callback' => 'sanitize_key',
                'auth_callback'     => static function () {
                    return current_user_can( 'edit_posts' );
                },
            )
        );
    }
}

/**
 * Sanitize relationship ID list meta values.
 *
 * @param mixed $value Raw value.
 * @return array<int,int>
 */
function themisdb_v3_sanitize_id_list_meta( $value ) {
    return themisdb_v3_normalize_id_list( $value );
}

add_action( 'add_meta_boxes', 'themisdb_v3_add_relationship_metabox' );
/**
 * Add relationship metabox on supported content types.
 */
function themisdb_v3_add_relationship_metabox() {
    foreach ( themisdb_v3_get_supported_content_post_types() as $post_type ) {
        add_meta_box(
            'themisdb-v3-relationships',
            __( 'Content Relationships', 'themisdb-v3' ),
            'themisdb_v3_render_relationship_metabox',
            $post_type,
            'side',
            'default'
        );
    }
}

/**
 * Get candidate posts for relationship autocomplete fields.
 *
 * @param array<int,string> $post_types Post types.
 * @param int               $limit Max records.
 * @return array<int,array<string,mixed>>
 */
function themisdb_v3_get_relationship_picker_items( array $post_types, $limit = 50 ) {
    $query = new WP_Query(
        array(
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            'posts_per_page'      => max( 1, absint( $limit ) ),
            'orderby'             => 'date',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
        )
    );

    $items = array();
    if ( ! $query->have_posts() ) {
        return $items;
    }

    foreach ( $query->posts as $item ) {
        $items[] = array(
            'id'    => (int) $item->ID,
            'title' => get_the_title( $item->ID ),
            'type'  => (string) $item->post_type,
        );
    }

    return $items;
}

/**
 * Render relationship fields in post editor.
 *
 * @param WP_Post $post Post object.
 */
function themisdb_v3_render_relationship_metabox( $post ) {
    wp_nonce_field( 'themisdb_v3_save_relationships', 'themisdb_v3_relationships_nonce' );

    $picker_id_suffix = (string) absint( $post->ID );
    $related_objects = implode( ', ', themisdb_v3_get_related_object_ids( $post->ID ) );
    $related_posts   = implode( ', ', themisdb_v3_get_related_post_ids( $post->ID ) );
    $object_type     = (string) get_post_meta( $post->ID, 'content_object_type', true );

    $object_types    = themisdb_v3_get_supported_object_post_types();

    $object_input_id  = 'themisdb-v3-object-pick-' . $picker_id_suffix;
    $post_input_id    = 'themisdb-v3-post-pick-' . $picker_id_suffix;
    $object_results_id = 'themisdb-v3-object-results-' . $picker_id_suffix;
    $post_results_id   = 'themisdb-v3-post-results-' . $picker_id_suffix;
    $objects_field_id = 'themisdb-v3-related-objects-' . $picker_id_suffix;
    $posts_field_id   = 'themisdb-v3-related-posts-' . $picker_id_suffix;
    $object_type_list = 'themisdb-v3-object-type-list-' . $picker_id_suffix;
    $ajax_nonce       = wp_create_nonce( 'themisdb_v3_relationship_search' );
    ?>
    <p>
        <label for="<?php echo esc_attr( $object_input_id ); ?>"><strong><?php esc_html_e( 'Objekt suchen und ID hinzufuegen', 'themisdb-v3' ); ?></strong></label>
        <input id="<?php echo esc_attr( $object_input_id ); ?>" type="text" style="width:100%;" placeholder="Podcast/Video/Tutorial nach Titel suchen" autocomplete="off" />
        <div id="<?php echo esc_attr( $object_results_id ); ?>" class="themisdb-v3-picker-results"></div>
    </p>
    <p>
        <label for="<?php echo esc_attr( $objects_field_id ); ?>"><strong><?php esc_html_e( 'Related object IDs', 'themisdb-v3' ); ?></strong></label>
        <input id="<?php echo esc_attr( $objects_field_id ); ?>" name="themisdb_v3_related_object_ids" type="text" value="<?php echo esc_attr( $related_objects ); ?>" style="width:100%;" placeholder="8, 9, 10" />
    </p>
    <p>
        <label for="<?php echo esc_attr( $post_input_id ); ?>"><strong><?php esc_html_e( 'Beitrag suchen und ID hinzufuegen', 'themisdb-v3' ); ?></strong></label>
        <input id="<?php echo esc_attr( $post_input_id ); ?>" type="text" style="width:100%;" placeholder="Artikel/Seite nach Titel suchen" autocomplete="off" />
        <div id="<?php echo esc_attr( $post_results_id ); ?>" class="themisdb-v3-picker-results"></div>
    </p>
    <p>
        <label for="<?php echo esc_attr( $posts_field_id ); ?>"><strong><?php esc_html_e( 'Related post IDs', 'themisdb-v3' ); ?></strong></label>
        <input id="<?php echo esc_attr( $posts_field_id ); ?>" name="themisdb_v3_related_post_ids" type="text" value="<?php echo esc_attr( $related_posts ); ?>" style="width:100%;" placeholder="1, 2" />
    </p>
    <p>
        <label for="themisdb-v3-object-type"><strong><?php esc_html_e( 'Object type', 'themisdb-v3' ); ?></strong></label>
        <input id="themisdb-v3-object-type" name="themisdb_v3_content_object_type" type="text" value="<?php echo esc_attr( $object_type ); ?>" style="width:100%;" list="<?php echo esc_attr( $object_type_list ); ?>" placeholder="podcast, video, screencast, tutorial" />
        <datalist id="<?php echo esc_attr( $object_type_list ); ?>">
            <?php foreach ( $object_types as $type ) : ?>
                <option value="<?php echo esc_attr( sanitize_key( $type ) ); ?>"><?php echo esc_html( themisdb_v3_get_content_type_label( $type ) ); ?></option>
            <?php endforeach; ?>
        </datalist>
    </p>
    <p style="margin-bottom:0;color:#50575e;">
        <?php esc_html_e( 'Dynamische Kriterien: Suche basiert auf vorhandenen Content-Typen und vorhandenen Titeln im System.', 'themisdb-v3' ); ?>
    </p>
    <style>
    .themisdb-v3-picker-results { margin-top: 0.35rem; display: grid; gap: 0.3rem; }
    .themisdb-v3-picker-result { width: 100%; text-align: left; border: 1px solid #d0d7de; background: #fff; border-radius: 6px; padding: 0.38rem 0.5rem; cursor: pointer; }
    .themisdb-v3-picker-result strong { display: block; }
    .themisdb-v3-picker-result span { color: #50575e; font-size: 11px; }
    </style>
    <script>
    (function(){
        var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
        var ajaxNonce = <?php echo wp_json_encode( $ajax_nonce ); ?>;

        function appendId(target, id){
            var raw = (target.value || '').trim();
            var parts = raw ? raw.split(/[\s,;|]+/) : [];
            var map = {};
            parts.forEach(function(part){
                var parsed = parseInt(part, 10);
                if(parsed){
                    map[String(parsed)] = true;
                }
            });
            map[String(id)] = true;

            var merged = Object.keys(map).map(function(key){ return parseInt(key, 10); }).filter(function(v){ return !!v; });
            merged.sort(function(a, b){ return a - b; });
            target.value = merged.join(', ');
        }

        function bindSearch(pickerId, resultsId, targetId, mode){
            var picker = document.getElementById(pickerId);
            var results = document.getElementById(resultsId);
            var target = document.getElementById(targetId);
            var timer = null;

            if(!picker || !results || !target){
                return;
            }

            picker.addEventListener('input', function(){
                var term = (picker.value || '').trim();
                results.innerHTML = '';

                if(timer){
                    clearTimeout(timer);
                }

                if(term.length < 2){
                    return;
                }

                timer = setTimeout(function(){
                    var url = ajaxUrl + '?action=themisdb_v3_search_relationship_targets&_ajax_nonce=' + encodeURIComponent(ajaxNonce) + '&mode=' + encodeURIComponent(mode) + '&term=' + encodeURIComponent(term);
                    fetch(url, { credentials: 'same-origin' })
                        .then(function(response){ return response.json(); })
                        .then(function(payload){
                            results.innerHTML = '';
                            if(!payload || !payload.success || !Array.isArray(payload.data)){
                                return;
                            }

                            payload.data.forEach(function(item){
                                var button = document.createElement('button');
                                button.type = 'button';
                                button.className = 'themisdb-v3-picker-result';
                                button.innerHTML = '<strong>' + item.title + '</strong><span>' + item.label + ' · ID ' + item.id + '</span>';
                                button.addEventListener('click', function(){
                                    appendId(target, parseInt(item.id, 10));
                                    picker.value = '';
                                    results.innerHTML = '';
                                });
                                results.appendChild(button);
                            });
                        });
                }, 180);
            });
        }

        bindSearch('<?php echo esc_js( $object_input_id ); ?>', '<?php echo esc_js( $object_results_id ); ?>', '<?php echo esc_js( $objects_field_id ); ?>', 'object');
        bindSearch('<?php echo esc_js( $post_input_id ); ?>', '<?php echo esc_js( $post_results_id ); ?>', '<?php echo esc_js( $posts_field_id ); ?>', 'post');
    })();
    </script>
    <?php
}

add_action( 'save_post', 'themisdb_v3_save_relationship_metabox' );
/**
 * Persist relationship fields from metabox.
 *
 * @param int $post_id Post ID.
 */
function themisdb_v3_save_relationship_metabox( $post_id ) {
    if ( ! isset( $_POST['themisdb_v3_relationships_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['themisdb_v3_relationships_nonce'] ) ), 'themisdb_v3_save_relationships' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $post_type = get_post_type( $post_id );
    if ( ! in_array( $post_type, themisdb_v3_get_supported_content_post_types(), true ) ) {
        return;
    }

    $object_ids_raw = isset( $_POST['themisdb_v3_related_object_ids'] ) ? wp_unslash( $_POST['themisdb_v3_related_object_ids'] ) : '';
    $post_ids_raw   = isset( $_POST['themisdb_v3_related_post_ids'] ) ? wp_unslash( $_POST['themisdb_v3_related_post_ids'] ) : '';
    $object_type_raw = isset( $_POST['themisdb_v3_content_object_type'] ) ? wp_unslash( $_POST['themisdb_v3_content_object_type'] ) : '';

    $old_object_ids = themisdb_v3_get_meta_id_list( $post_id, 'related_object_ids' );
    $old_post_ids   = themisdb_v3_get_meta_id_list( $post_id, 'related_post_ids' );

    $object_ids = themisdb_v3_normalize_id_list( $object_ids_raw );
    $post_ids   = themisdb_v3_normalize_id_list( $post_ids_raw );
    $object_type = sanitize_key( (string) $object_type_raw );

    if ( ! empty( $object_ids ) ) {
        update_post_meta( $post_id, 'related_object_ids', $object_ids );
    } else {
        delete_post_meta( $post_id, 'related_object_ids' );
    }

    if ( ! empty( $post_ids ) ) {
        update_post_meta( $post_id, 'related_post_ids', $post_ids );
    } else {
        delete_post_meta( $post_id, 'related_post_ids' );
    }

    if ( '' !== $object_type ) {
        update_post_meta( $post_id, 'content_object_type', $object_type );
    } else {
        delete_post_meta( $post_id, 'content_object_type' );
    }

    themisdb_v3_sync_bidirectional_relationships( $post_id, $old_object_ids, $object_ids, $old_post_ids, $post_ids );
}

add_filter( 'themisdb_persistent_podcast_player_html', 'themisdb_v3_hide_persistent_podcast_player', 10, 2 );
function themisdb_v3_hide_persistent_podcast_player( $html, $payload ) {
    return '';
}

add_filter( 'themisdb_persistent_podcast_player_enqueue_frontend_style', '__return_false' );

add_action( 'wp_enqueue_scripts', 'themisdb_v3_dequeue_persistent_podcast_player_assets', 100 );
function themisdb_v3_dequeue_persistent_podcast_player_assets() {
    wp_dequeue_style( 'ppp-player-style' );
    wp_deregister_style( 'ppp-player-style' );
    wp_dequeue_script( 'ppp-player-script' );
    wp_deregister_script( 'ppp-player-script' );
}

/**
 * Extend the front-page query block to include mixed content types.
 */
add_filter( 'query_loop_block_query_vars', 'themisdb_v3_mixed_frontpage_query', 10, 2 );
function themisdb_v3_mixed_frontpage_query( $query, $block ) {
    if ( ! is_array( $query ) ) {
        return $query;
    }

    $class_name = '';
    if ( is_object( $block ) && isset( $block->parsed_block['attrs']['className'] ) ) {
        $class_name = (string) $block->parsed_block['attrs']['className'];
    } elseif ( is_array( $block ) && isset( $block['attrs']['className'] ) ) {
        $class_name = (string) $block['attrs']['className'];
    }

    if ( false === strpos( $class_name, 'tv3-query-mixed' ) ) {
        return $query;
    }

    $post_types = themisdb_v3_get_supported_content_post_types();

    $query['post_type']      = $post_types;
    $query['post_status']    = 'publish';
    $query['orderby']        = 'date';
    $query['order']          = 'DESC';
    $query['no_found_rows']  = false;
    $query['suppress_filters'] = false;

    return $query;
}

/**
 * Fallback: enforce mixed content on front-page non-main post queries.
 */
add_action( 'pre_get_posts', 'themisdb_v3_mixed_frontpage_query_fallback', 20 );
function themisdb_v3_mixed_frontpage_query_fallback( $query ) {
    if ( is_admin() || ! ( $query instanceof WP_Query ) || $query->is_main_query() ) {
        return;
    }

    if ( ! is_front_page() ) {
        return;
    }

    $configured_type = $query->get( 'post_type' );
    if ( empty( $configured_type ) ) {
        return;
    }

    $is_post_only = ( 'post' === $configured_type ) || ( is_array( $configured_type ) && 1 === count( $configured_type ) && 'post' === reset( $configured_type ) );
    if ( ! $is_post_only ) {
        return;
    }

    $post_types = themisdb_v3_get_supported_content_post_types();

    $query->set( 'post_type', $post_types );
    $query->set( 'post_status', 'publish' );
    $query->set( 'orderby', 'date' );
    $query->set( 'order', 'DESC' );
}

/**
 * Build score and overlay metrics for a card from WordPress data and post meta.
 *
 * @param int $post_id Post ID.
 * @return array<string,mixed>
 */
function themisdb_v3_get_card_metrics( $post_id ) {
    $post_type      = get_post_type( $post_id );
    $featured_meta  = get_post_meta( $post_id, 'featured', true );
    $relevance_meta = absint( get_post_meta( $post_id, 'relevance_score', true ) );
    $priority_meta  = absint( get_post_meta( $post_id, 'priority', true ) );
    $relationship_count = themisdb_v3_get_relationship_count( $post_id );
    $audio_url      = (string) get_post_meta( $post_id, 'audio_url', true );
    $comment_count  = (int) get_comments_number( $post_id );
    $tag_terms      = get_the_terms( $post_id, 'post_tag' );
    $tag_count      = ( ! empty( $tag_terms ) && ! is_wp_error( $tag_terms ) ) ? count( $tag_terms ) : 0;
    $days_since     = max( 0, (int) floor( ( time() - get_post_timestamp( $post_id ) ) / DAY_IN_SECONDS ) );
    $is_featured    = in_array( (string) $featured_meta, array( '1', 'true', 'yes', 'on' ), true ) || is_sticky( $post_id );

    $bookmark_score = $relevance_meta;
    if ( $bookmark_score <= 0 ) {
        $bookmark_score = min(
            99,
            20 +
            ( $comment_count * 6 ) +
            ( $tag_count * 4 ) +
            ( has_post_thumbnail( $post_id ) ? 8 : 0 ) +
            ( $is_featured ? 12 : 0 ) +
            ( ! empty( $audio_url ) ? 10 : 0 ) +
            min( 18, $relationship_count * 4 )
        );
    }

    $star_score = $priority_meta > 0 ? min( 5, max( 1, $priority_meta / 2 ) ) : 0;
    if ( $star_score <= 0 ) {
        $star_score = min(
            5,
            max(
                1,
                2.8 +
                ( $is_featured ? 0.8 : 0 ) +
                min( 0.9, $comment_count / 10 ) +
                min( 0.5, $tag_count / 8 ) +
                ( ! empty( $audio_url ) ? 0.4 : 0 ) +
                ( $days_since <= 14 ? 0.2 : 0 )
            )
        );
    }

    $relevance_score = min(
        100,
        max(
            0,
            $bookmark_score +
            ( $star_score * 12 ) +
            ( $is_featured ? 12 : 0 ) +
            ( 'pod_episode' === $post_type ? 6 : 0 ) -
            min( 18, $days_since ) +
            min( 16, $relationship_count * 3 )
        )
    );

    return array(
        'post_type'        => $post_type,
        'tag_terms'        => $tag_terms,
        'tag_count'        => $tag_count,
        'days_since'       => $days_since,
        'is_featured'      => $is_featured,
        'relationship_count' => $relationship_count,
        'bookmark_score'   => $bookmark_score,
        'star_score'       => $star_score,
        'relevance_score'  => $relevance_score,
    );
}

/**
 * Normalize ID list values from array/json/csv/meta formats.
 *
 * @param mixed $value Raw value.
 * @return array<int,int>
 */
function themisdb_v3_normalize_id_list( $value ) {
    $ids = array();

    if ( is_array( $value ) ) {
        foreach ( $value as $item ) {
            $ids = array_merge( $ids, themisdb_v3_normalize_id_list( $item ) );
        }
    } elseif ( is_string( $value ) ) {
        $trimmed = trim( $value );

        if ( '' === $trimmed ) {
            return array();
        }

        if ( '[' === substr( $trimmed, 0, 1 ) ) {
            $decoded = json_decode( $trimmed, true );
            if ( is_array( $decoded ) ) {
                return themisdb_v3_normalize_id_list( $decoded );
            }
        }

        $parts = preg_split( '/[\s,;|]+/', $trimmed );
        if ( is_array( $parts ) ) {
            foreach ( $parts as $part ) {
                $id = absint( $part );
                if ( $id > 0 ) {
                    $ids[] = $id;
                }
            }
        }
    } else {
        $id = absint( $value );
        if ( $id > 0 ) {
            $ids[] = $id;
        }
    }

    return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Get clean ID list directly from one meta key.
 *
 * @param int    $post_id Post ID.
 * @param string $meta_key Meta key.
 * @return array<int,int>
 */
function themisdb_v3_get_meta_id_list( $post_id, $meta_key ) {
    $single = get_post_meta( $post_id, $meta_key, true );
    $multi  = get_post_meta( $post_id, $meta_key, false );

    return array_values(
        array_unique(
            array_merge(
                themisdb_v3_normalize_id_list( $single ),
                themisdb_v3_normalize_id_list( $multi )
            )
        )
    );
}

/**
 * Check whether post type is treated as content object (not post/page).
 *
 * @param string $post_type Post type.
 * @return bool
 */
function themisdb_v3_is_object_content_type( $post_type ) {
    return ! in_array( $post_type, array( 'post', 'page' ), true );
}

/**
 * Resolve backlink meta key to keep relationships bidirectional.
 *
 * @param string $source_type Source post type.
 * @param string $target_type Target post type.
 * @return string
 */
function themisdb_v3_get_backlink_meta_key( $source_type, $target_type ) {
    $source_is_object = themisdb_v3_is_object_content_type( (string) $source_type );
    $target_is_object = themisdb_v3_is_object_content_type( (string) $target_type );

    if ( $source_is_object && ! $target_is_object ) {
        return 'related_object_ids';
    }

    if ( ! $source_is_object && $target_is_object ) {
        return 'related_post_ids';
    }

    return $source_is_object ? 'related_object_ids' : 'related_post_ids';
}

/**
 * Synchronize forward relationship changes to targets.
 *
 * @param int              $source_id Source post ID.
 * @param array<int,int>   $old_targets Previous target IDs.
 * @param array<int,int>   $new_targets New target IDs.
 */
function themisdb_v3_sync_relationship_set( $source_id, array $old_targets, array $new_targets ) {
    $source_type = (string) get_post_type( $source_id );
    $all_targets = array_values( array_unique( array_merge( $old_targets, $new_targets ) ) );

    foreach ( $all_targets as $target_id ) {
        $target_id = absint( $target_id );
        if ( $target_id <= 0 || $target_id === (int) $source_id ) {
            continue;
        }

        $target = get_post( $target_id );
        if ( ! $target ) {
            continue;
        }

        $target_type = (string) $target->post_type;
        $meta_key    = themisdb_v3_get_backlink_meta_key( $source_type, $target_type );
        $target_ids  = themisdb_v3_get_meta_id_list( $target_id, $meta_key );
        $should_have = in_array( $target_id, $new_targets, true );

        if ( $should_have && ! in_array( (int) $source_id, $target_ids, true ) ) {
            $target_ids[] = (int) $source_id;
        }

        if ( ! $should_have && in_array( (int) $source_id, $target_ids, true ) ) {
            $target_ids = array_values( array_diff( $target_ids, array( (int) $source_id ) ) );
        }

        if ( ! empty( $target_ids ) ) {
            update_post_meta( $target_id, $meta_key, array_values( array_unique( array_map( 'absint', $target_ids ) ) ) );
        } else {
            delete_post_meta( $target_id, $meta_key );
        }
    }
}

/**
 * Keep related object/post IDs bidirectional after save.
 *
 * @param int            $post_id Post ID.
 * @param array<int,int> $old_object_ids Old related objects.
 * @param array<int,int> $new_object_ids New related objects.
 * @param array<int,int> $old_post_ids Old related posts.
 * @param array<int,int> $new_post_ids New related posts.
 */
function themisdb_v3_sync_bidirectional_relationships( $post_id, array $old_object_ids, array $new_object_ids, array $old_post_ids, array $new_post_ids ) {
    themisdb_v3_sync_relationship_set( $post_id, $old_object_ids, $new_object_ids );
    themisdb_v3_sync_relationship_set( $post_id, $old_post_ids, $new_post_ids );
}

/**
 * Build available card filters from the current query result set.
 *
 * @param array<int,WP_Post> $posts Active mixed feed posts.
 * @return array<string,array<string,mixed>>
 */
function themisdb_v3_get_card_type_filters( array $posts ) {
    $supported_types = themisdb_v3_get_supported_content_post_types();
    $counts          = array();

    foreach ( $posts as $post ) {
        if ( ! $post instanceof WP_Post ) {
            continue;
        }

        $post_type = (string) $post->post_type;
        if ( '' === $post_type || ! post_type_exists( $post_type ) ) {
            continue;
        }

        if ( ! isset( $counts[ $post_type ] ) ) {
            $counts[ $post_type ] = 0;
        }

        $counts[ $post_type ]++;
    }

    $visible_post_types = array_values( array_intersect( $supported_types, array_keys( $counts ) ) );

    $filters = array(
        'all' => array(
            'label' => __( 'Alle', 'themisdb-v3' ),
            'types' => $visible_post_types,
            'count' => array_sum( $counts ),
        ),
    );

    foreach ( $visible_post_types as $post_type ) {
        $filters[ sanitize_key( $post_type ) ] = array(
            'label' => themisdb_v3_get_content_type_label( $post_type ),
            'types' => array( $post_type ),
            'count' => (int) $counts[ $post_type ],
        );
    }

    return $filters;
}

/**
 * Get outbound linked object IDs for a post.
 *
 * @param int $post_id Post ID.
 * @return array<int,int>
 */
function themisdb_v3_get_related_object_ids( $post_id ) {
    $ids = array();

    $raw_single = get_post_meta( $post_id, 'related_object_ids', true );
    $raw_multi  = get_post_meta( $post_id, 'related_object_ids', false );

    $ids = array_merge( $ids, themisdb_v3_normalize_id_list( $raw_single ) );
    $ids = array_merge( $ids, themisdb_v3_normalize_id_list( $raw_multi ) );

    // Backward compatibility for older single-link meta.
    $legacy_related = absint( get_post_meta( $post_id, 'related_post_id', true ) );
    if ( $legacy_related > 0 ) {
        $ids[] = $legacy_related;
    }

    return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Get related post IDs stored on content objects.
 *
 * @param int $post_id Post ID.
 * @return array<int,int>
 */
function themisdb_v3_get_related_post_ids( $post_id ) {
    $ids = array();

    $raw_single = get_post_meta( $post_id, 'related_post_ids', true );
    $raw_multi  = get_post_meta( $post_id, 'related_post_ids', false );

    $ids = array_merge( $ids, themisdb_v3_normalize_id_list( $raw_single ) );
    $ids = array_merge( $ids, themisdb_v3_normalize_id_list( $raw_multi ) );

    return array_values( array_unique( array_filter( $ids ) ) );
}

/**
 * Get total relationship links attached to an item.
 *
 * @param int $post_id Post ID.
 * @return int
 */
function themisdb_v3_get_relationship_count( $post_id ) {
    $related = array_merge(
        themisdb_v3_get_related_object_ids( $post_id ),
        themisdb_v3_get_related_post_ids( $post_id )
    );

    return count( array_unique( array_filter( array_map( 'absint', $related ) ) ) );
}

/**
 * Resolve the best available inline audio source for an episode card.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function themisdb_v3_get_episode_audio_url( $post_id ) {
    $audio_url = (string) get_post_meta( $post_id, 'audio_url', true );
    if ( ! empty( $audio_url ) ) {
        return $audio_url;
    }

    $attachment_id = absint( get_post_meta( $post_id, 'audio_attachment_id', true ) );
    if ( $attachment_id > 0 ) {
        $attachment_url = wp_get_attachment_url( $attachment_id );
        if ( ! empty( $attachment_url ) ) {
            return (string) $attachment_url;
        }
    }

    return '';
}

/**
 * Resolve a compact duration label for an episode audio file.
 *
 * @param int $post_id Post ID.
 * @return string
 */
function themisdb_v3_get_episode_duration_label( $post_id ) {
    $attachment_id = absint( get_post_meta( $post_id, 'audio_attachment_id', true ) );
    if ( $attachment_id > 0 ) {
        $metadata = wp_get_attachment_metadata( $attachment_id );
        if ( is_array( $metadata ) && ! empty( $metadata['length_formatted'] ) ) {
            return (string) $metadata['length_formatted'];
        }
    }

    return 'Audio';
}

function themisdb_v3_get_mixed_cards_sort_options() {
    return array(
        'relevance'  => __( 'Relevanz', 'themisdb-v3' ),
        'newest'     => __( 'Neueste zuerst', 'themisdb-v3' ),
        'oldest'     => __( 'Aelteste zuerst', 'themisdb-v3' ),
        'title_asc'  => __( 'Titel A-Z', 'themisdb-v3' ),
        'title_desc' => __( 'Titel Z-A', 'themisdb-v3' ),
    );
}

/**
 * Normalize current mixed-card request state.
 *
 * @param array<string,mixed> $atts Shortcode attributes.
 * @param array<string,mixed> $request Optional request overrides.
 * @return array<string,mixed>
 */
function themisdb_v3_get_mixed_cards_state( array $atts = array(), array $request = array() ) {
    $sort_options = themisdb_v3_get_mixed_cards_sort_options();
    $raw_request  = ! empty( $request ) ? $request : wp_unslash( $_GET );

    $limit = isset( $raw_request['tv3_limit'] ) ? absint( $raw_request['tv3_limit'] ) : absint( $atts['limit'] ?? 12 );
    $limit = max( 4, min( 24, $limit ) );

    $page = isset( $raw_request['tv3_page'] ) ? absint( $raw_request['tv3_page'] ) : 1;
    $page = max( 1, $page );

    $filter = isset( $raw_request['tv3_object_type'] ) ? sanitize_key( (string) $raw_request['tv3_object_type'] ) : sanitize_key( (string) ( $atts['type'] ?? 'all' ) );
    $filter = '' !== $filter ? $filter : 'all';

    $search = isset( $raw_request['tv3_search'] ) ? sanitize_text_field( (string) $raw_request['tv3_search'] ) : '';
    $sort   = isset( $raw_request['tv3_sort'] ) ? sanitize_key( (string) $raw_request['tv3_sort'] ) : 'relevance';

    if ( ! isset( $sort_options[ $sort ] ) ) {
        $sort = 'relevance';
    }

    $source_id = isset( $raw_request['tv3_source_id'] ) ? absint( $raw_request['tv3_source_id'] ) : 0;
    if ( $source_id <= 0 ) {
        $source_id = themisdb_v3_get_mixed_cards_source_id();
    }

    return array(
        'limit'  => $limit,
        'page'   => $page,
        'filter' => $filter,
        'search' => $search,
        'sort'   => $sort,
        'source_id' => $source_id,
    );
}

/**
 * Sort mixed card posts according to the active frontend sort setting.
 *
 * @param array<int,WP_Post> $posts Posts to sort.
 * @param string             $sort Sort key.
 * @return array<int,WP_Post>
 */
function themisdb_v3_sort_mixed_card_posts( array $posts, $sort ) {
    if ( 'oldest' === $sort ) {
        usort(
            $posts,
            static function ( $left, $right ) {
                return strcmp( $left->post_date_gmt, $right->post_date_gmt );
            }
        );

        return $posts;
    }

    if ( 'title_asc' === $sort || 'title_desc' === $sort ) {
        usort(
            $posts,
            static function ( $left, $right ) use ( $sort ) {
                $comparison = strcasecmp( get_the_title( $left->ID ), get_the_title( $right->ID ) );
                return 'title_desc' === $sort ? -1 * $comparison : $comparison;
            }
        );

        return $posts;
    }

    if ( 'newest' === $sort ) {
        usort(
            $posts,
            static function ( $left, $right ) {
                return strcmp( $right->post_date_gmt, $left->post_date_gmt );
            }
        );

        return $posts;
    }

    usort(
        $posts,
        static function ( $left, $right ) {
            $left_metrics  = themisdb_v3_get_card_metrics( $left->ID );
            $right_metrics = themisdb_v3_get_card_metrics( $right->ID );

            if ( $left_metrics['relevance_score'] === $right_metrics['relevance_score'] ) {
                return strcmp( $right->post_date_gmt, $left->post_date_gmt );
            }

            return $right_metrics['relevance_score'] <=> $left_metrics['relevance_score'];
        }
    );

    return $posts;
}

/**
 * Build current base URL without mixed-card query parameters.
 *
 * @return string
 */
function themisdb_v3_get_mixed_cards_base_url() {
    if ( isset( $_REQUEST['tv3_source_id'] ) ) {
        $source_id = absint( wp_unslash( $_REQUEST['tv3_source_id'] ) );
        if ( $source_id > 0 ) {
            $source_url = get_permalink( $source_id );
            if ( ! empty( $source_url ) ) {
                return (string) $source_url;
            }
        }
    }

    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
    $path        = strtok( $request_uri, '?' );

    if ( false === $path || '' === $path ) {
        $path = '/';
    }

    if ( false !== strpos( $path, 'admin-ajax.php' ) ) {
        $referer = wp_get_referer();
        if ( $referer ) {
            $parsed_referer = wp_parse_url( $referer );
            $referer_path   = isset( $parsed_referer['path'] ) ? (string) $parsed_referer['path'] : '';
            if ( '' !== $referer_path ) {
                return home_url( $referer_path );
            }
        }

        return home_url( '/' );
    }

    return home_url( $path );
}

/**
 * Resolve the canonical source page ID for mixed cards.
 *
 * @return int
 */
function themisdb_v3_get_mixed_cards_source_id() {
    $front_page_id = (int) get_option( 'page_on_front' );
    if ( is_front_page() && $front_page_id > 0 ) {
        return $front_page_id;
    }

    $posts_page_id = (int) get_option( 'page_for_posts' );
    if ( is_home() && $posts_page_id > 0 ) {
        return $posts_page_id;
    }

    $source_id = get_queried_object_id();

    if ( $source_id > 0 ) {
        return (int) $source_id;
    }

    return 0;
}

/**
 * Build a mixed-card URL for filter/sort/search navigation.
 *
 * @param array<string,mixed> $state Current state.
 * @param array<string,mixed> $overrides Replacement state values.
 * @return string
 */
function themisdb_v3_get_mixed_cards_url( array $state, array $overrides = array() ) {
    $args = array_merge( $state, $overrides );
    $url_args = array(
        'tv3_limit' => (int) $args['limit'],
    );

    if ( ! empty( $args['search'] ) ) {
        $url_args['tv3_search'] = (string) $args['search'];
    }

    if ( ! empty( $args['sort'] ) && 'relevance' !== $args['sort'] ) {
        $url_args['tv3_sort'] = (string) $args['sort'];
    }

    if ( ! empty( $args['filter'] ) && 'all' !== $args['filter'] ) {
        $url_args['tv3_object_type'] = (string) $args['filter'];
    }

    if ( ! empty( $args['page'] ) && (int) $args['page'] > 1 ) {
        $url_args['tv3_page'] = (int) $args['page'];
    }

    return add_query_arg( $url_args, themisdb_v3_get_mixed_cards_base_url() );
}

/**
 * Query and prepare the full mixed-card result set.
 *
 * @param array<string,mixed> $state Current frontend state.
 * @return array<string,mixed>
 */
function themisdb_v3_prepare_mixed_cards_data( array $state ) {
    $query = new WP_Query(
        array(
            'post_type'           => themisdb_v3_get_supported_content_post_types(),
            'post_status'         => 'publish',
            'posts_per_page'      => -1,
            'orderby'             => 'date',
            'order'               => 'DESC',
            'ignore_sticky_posts' => true,
            's'                   => (string) $state['search'],
            'no_found_rows'       => true,
        )
    );

    $posts   = $query->posts;
    $filters = themisdb_v3_get_card_type_filters( $posts );

    if ( ! isset( $filters[ $state['filter'] ] ) ) {
        $state['filter'] = 'all';
    }

    if ( 'all' !== $state['filter'] ) {
        $allowed_types = $filters[ $state['filter'] ]['types'];
        $posts         = array_values(
            array_filter(
                $posts,
                static function ( $post ) use ( $allowed_types ) {
                    return $post instanceof WP_Post && in_array( (string) $post->post_type, $allowed_types, true );
                }
            )
        );
    }

    $posts       = themisdb_v3_sort_mixed_card_posts( $posts, (string) $state['sort'] );
    $total       = count( $posts );
    $total_pages = max( 1, (int) ceil( $total / (int) $state['limit'] ) );
    $page        = min( (int) $state['page'], $total_pages );
    $offset      = ( $page - 1 ) * (int) $state['limit'];
    $page_posts  = array_slice( $posts, $offset, (int) $state['limit'] );

    return array(
        'state'       => array_merge( $state, array( 'page' => $page ) ),
        'posts'       => $page_posts,
        'filters'     => $filters,
        'total'       => $total,
        'page'        => $page,
        'total_pages' => $total_pages,
        'has_more'    => $page < $total_pages,
    );
}

/**
 * Render the mixed-card grid items.
 *
 * @param array<int,WP_Post> $posts Posts to render.
 * @return string
 */
function themisdb_v3_render_mixed_cards_grid( array $posts ) {
    if ( empty( $posts ) ) {
        return '<div class="tv3-card-empty"><p>Keine Inhalte fuer diese Auswahl gefunden.</p></div>';
    }

    ob_start();
    ?>
    <ul class="tv3-post-grid wp-block-post-template is-layout-grid">
        <?php
        $card_index    = 0;
        $hero_assigned = false;
        foreach ( $posts as $post ) {
            $post_id           = $post->ID;
            $title             = get_the_title( $post_id );
            $permalink         = get_permalink( $post_id );
            $thumb_html        = get_the_post_thumbnail( $post_id, 'large' );
            $date              = get_the_date( '', $post_id );
            $date_iso          = get_the_date( 'c', $post_id );
            $author_id         = (int) get_post_field( 'post_author', $post_id );
            $author            = get_the_author_meta( 'display_name', $author_id );
            $episode_audio_url = 'pod_episode' === get_post_type( $post_id ) ? themisdb_v3_get_episode_audio_url( $post_id ) : '';
            $episode_duration  = 'pod_episode' === get_post_type( $post_id ) ? themisdb_v3_get_episode_duration_label( $post_id ) : '';
            $author_face       = get_avatar(
                $author_id,
                48,
                '',
                $author,
                array(
                    'class' => 'tv3-card-author-avatar',
                )
            );
            $excerpt            = get_the_excerpt( $post_id );
            $metrics            = themisdb_v3_get_card_metrics( $post_id );
            $post_type          = $metrics['post_type'];
            $is_hero            = false;
            $relevance_size     = 'tv3-card-size-md';
            $tag_terms          = $metrics['tag_terms'];
            $days_since         = $metrics['days_since'];
            $is_featured        = $metrics['is_featured'];
            $badge_label        = 'Article';
            $badge_class        = 'tv3-card-badge-standard';
            $bookmark_score     = $metrics['bookmark_score'];
            $star_score         = $metrics['star_score'];
            $relevance_score    = $metrics['relevance_score'];
            $relationship_count = $metrics['relationship_count'];

            if ( ! $hero_assigned && $relevance_score >= 88 ) {
                $is_hero        = true;
                $hero_assigned  = true;
                $relevance_size = 'tv3-card-hero';
            } elseif ( $relevance_score >= 68 ) {
                $relevance_size = 'tv3-card-size-lg';
            } elseif ( $relevance_score <= 38 ) {
                $relevance_size = 'tv3-card-size-sm';
            }

            if ( ! $hero_assigned && 0 === $card_index ) {
                $is_hero        = true;
                $hero_assigned  = true;
                $relevance_size = 'tv3-card-hero';
            }

            if ( $is_hero ) {
                $badge_label = 'Hero';
                $badge_class = 'tv3-card-badge-hero';
            } elseif ( 'pod_episode' === $post_type ) {
                $badge_label = 'Podcast';
                $badge_class = 'tv3-card-badge-podcast';
            } elseif ( in_array( $post_type, array( 'video', 'pod_video' ), true ) ) {
                $badge_label = 'Video';
                $badge_class = 'tv3-card-badge-podcast';
            } elseif ( 'screencast' === $post_type ) {
                $badge_label = 'Screencast';
                $badge_class = 'tv3-card-badge-guide';
            } elseif ( 'tutorial' === $post_type ) {
                $badge_label = 'Tutorial';
                $badge_class = 'tv3-card-badge-guide';
            } elseif ( $is_featured ) {
                $badge_label = 'Featured';
                $badge_class = 'tv3-card-badge-featured';
            } elseif ( 'page' === $post_type ) {
                $badge_label = 'Guide';
                $badge_class = 'tv3-card-badge-guide';
            } elseif ( $days_since <= 7 ) {
                $badge_label = 'Fresh';
                $badge_class = 'tv3-card-badge-fresh';
            }

            $item_classes = trim(
                'tv3-card-item ' .
                $relevance_size .
                ' wp-block-post ' .
                implode( ' ', get_post_class( '', $post_id ) )
            );
            ?>
            <li class="<?php echo esc_attr( $item_classes ); ?>">
                <article class="wp-block-group tv3-card">
                    <div class="wp-block-group tv3-card-media">
                        <div class="tv3-card-overlay-top">
                            <div class="tv3-card-badges">
                                <span class="tv3-card-badge <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( $badge_label ); ?></span>
                            </div>
                            <div class="tv3-card-signals" aria-label="Card relevance signals">
                                <span class="tv3-card-signal tv3-card-signal-bookmark"><span class="tv3-card-signal-icon" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false" aria-hidden="true"><path d="M4 2.5h8a1 1 0 0 1 1 1V14l-5-2.8L3 14V3.5a1 1 0 0 1 1-1Z" fill="currentColor"/></svg></span><span><?php echo esc_html( (string) $bookmark_score ); ?></span></span>
                                <?php if ( $relationship_count > 0 ) : ?>
                                    <span class="tv3-card-signal tv3-card-signal-bookmark" title="Linked objects"><span class="tv3-card-signal-icon" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false" aria-hidden="true"><path d="M6.2 5.1a2.5 2.5 0 0 1 3.53 0l1.17 1.17a2.5 2.5 0 0 1 0 3.53l-1.6 1.6a2.5 2.5 0 0 1-3.53 0l-.35-.34a.8.8 0 1 1 1.13-1.13l.35.35a.9.9 0 0 0 1.27 0l1.6-1.6a.9.9 0 0 0 0-1.27L8.6 6.24a.9.9 0 0 0-1.27 0l-1.1 1.1a.8.8 0 0 1-1.13-1.13l1.1-1.1Z" fill="currentColor"/><path d="M9.8 10.9a2.5 2.5 0 0 1-3.53 0L5.1 9.73a2.5 2.5 0 0 1 0-3.53l1.6-1.6a2.5 2.5 0 0 1 3.53 0l.35.34a.8.8 0 1 1-1.13 1.13l-.35-.35a.9.9 0 0 0-1.27 0l-1.6 1.6a.9.9 0 0 0 0 1.27l1.17 1.17a.9.9 0 0 0 1.27 0l1.1-1.1a.8.8 0 1 1 1.13 1.13l-1.1 1.1Z" fill="currentColor"/></svg></span><span><?php echo esc_html( (string) $relationship_count ); ?></span></span>
                                <?php endif; ?>
                                <span class="tv3-card-signal tv3-card-signal-star"><span class="tv3-card-signal-icon" aria-hidden="true"><svg viewBox="0 0 16 16" focusable="false" aria-hidden="true"><path d="m8 1.6 1.88 3.81 4.2.61-3.04 2.96.72 4.18L8 11.18l-3.76 1.98.72-4.18L1.92 6.02l4.2-.61L8 1.6Z" fill="currentColor"/></svg></span><span><?php echo esc_html( number_format_i18n( $star_score, 1 ) ); ?></span></span>
                            </div>
                        </div>
                        <?php if ( ! empty( $thumb_html ) ) : ?>
                            <figure class="wp-block-post-featured-image"><a href="<?php echo esc_url( $permalink ); ?>"><?php echo $thumb_html; ?></a></figure>
                        <?php endif; ?>
                        <div class="tv3-card-title-wrap">
                            <div class="tv3-card-article-wrapper">
                                <div class="tv3-card-author-row"><span class="tv3-card-author-face"><?php echo $author_face; ?></span><span class="tv3-card-author-badge"><?php echo esc_html( $author ); ?></span></div>
                                <div class="tv3-card-copy"><h3 class="tv3-card-title wp-block-post-title"><a class="tv3-card-copy-link" href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></h3><div class="tv3-card-date-line teaser_content"><time datetime="<?php echo esc_attr( $date_iso ); ?>"><?php echo esc_html( $date ); ?></time></div></div>
                            </div>
                        </div>
                    </div>
                    <div class="wp-block-group tv3-card-body">
                        <?php if ( ! empty( $episode_audio_url ) ) : ?>
                            <div class="tv3-card-audio"><div class="tv3-card-audio-meta"><span class="tv3-card-audio-label">Episode Audio</span><span class="tv3-card-audio-duration"><?php echo esc_html( $episode_duration ); ?></span></div><?php echo wp_audio_shortcode( array( 'src' => esc_url( $episode_audio_url ), 'preload' => 'none' ) ); ?></div>
                        <?php endif; ?>
                        <?php if ( ! empty( $excerpt ) ) : ?>
                            <div class="tv3-card-excerpt wp-block-post-excerpt"><p class="wp-block-post-excerpt__excerpt"><?php echo esc_html( $excerpt ); ?></p><p class="wp-block-post-excerpt__more-text"><a class="wp-block-post-excerpt__more-link" href="<?php echo esc_url( $permalink ); ?>">Weiterlesen</a></p></div>
                        <?php endif; ?>
                        <?php if ( ! empty( $tag_terms ) && ! is_wp_error( $tag_terms ) ) : ?>
                            <div class="tv3-card-tags wp-block-post-terms"><?php $term_links = array(); foreach ( array_slice( $tag_terms, 0, 4 ) as $term ) { $term_links[] = '<a href="' . esc_url( get_term_link( $term ) ) . '">' . esc_html( $term->name ) . '</a>'; } echo implode( '<span class="wp-block-post-terms__separator">, </span>', $term_links ); ?></div>
                        <?php endif; ?>
                    </div>
                </article>
            </li>
            <?php
            $card_index++;
        }
        ?>
    </ul>
    <?php

    $html = trim( (string) ob_get_clean() );
    return (string) preg_replace( '/>\s+</', '><', $html );
}

/**
 * Render filter, search and sort controls for mixed cards.
 *
 * @param array<string,mixed> $data Prepared query data.
 * @return string
 */
function themisdb_v3_render_mixed_cards_controls( array $data ) {
    $state        = $data['state'];
    $sort_options = themisdb_v3_get_mixed_cards_sort_options();

    ob_start();
    ?>
    <div class="tv3-card-toolbar-row">
        <form class="tv3-card-toolbar" method="get" action="<?php echo esc_url( themisdb_v3_get_mixed_cards_base_url() ); ?>" data-tv3-search-form>
            <input type="hidden" name="tv3_limit" value="<?php echo esc_attr( (string) $state['limit'] ); ?>" />
            <input type="hidden" name="tv3_page" value="1" />
            <input type="hidden" name="tv3_source_id" value="<?php echo esc_attr( (string) ( $state['source_id'] ?? 0 ) ); ?>" />
            <input type="hidden" name="tv3_object_type" value="<?php echo esc_attr( 'all' === $state['filter'] ? '' : (string) $state['filter'] ); ?>" data-tv3-filter-input />
            <label class="tv3-card-control tv3-card-search"><span class="screen-reader-text"><?php esc_html_e( 'Inhalte durchsuchen', 'themisdb-v3' ); ?></span><input type="search" name="tv3_search" value="<?php echo esc_attr( (string) $state['search'] ); ?>" placeholder="<?php echo esc_attr__( 'Titel oder Inhalt durchsuchen', 'themisdb-v3' ); ?>" data-tv3-search-input /></label>
            <label class="tv3-card-control tv3-card-sort"><span class="screen-reader-text"><?php esc_html_e( 'Sortierung', 'themisdb-v3' ); ?></span><select name="tv3_sort" data-tv3-sort-select><?php foreach ( $sort_options as $sort_key => $sort_label ) : ?><option value="<?php echo esc_attr( $sort_key ); ?>"<?php selected( $state['sort'], $sort_key ); ?>><?php echo esc_html( $sort_label ); ?></option><?php endforeach; ?></select></label>
        </form>
        <?php if ( count( $data['filters'] ) > 1 ) : ?>
        <nav class="tv3-card-filters tv3-card-filters-inline" aria-label="Content filter">
            <?php foreach ( $data['filters'] as $slug => $config ) : ?>
                <?php $active_class = $state['filter'] === $slug ? ' is-active' : ''; ?>
                <a class="tv3-card-filter<?php echo esc_attr( $active_class ); ?>" href="<?php echo esc_url( themisdb_v3_get_mixed_cards_url( $state, array( 'filter' => $slug, 'page' => 1 ) ) ); ?>" data-tv3-filter="<?php echo esc_attr( $slug ); ?>"><span><?php echo esc_html( $config['label'] ); ?></span><span class="tv3-card-filter-count"><?php echo esc_html( (string) ( $config['count'] ?? 0 ) ); ?></span></a>
            <?php endforeach; ?>
        </nav>
        <?php endif; ?>
        <p class="tv3-card-results-count"><?php echo esc_html( sprintf( _n( '%d Inhalt', '%d Inhalte', (int) $data['total'], 'themisdb-v3' ), (int) $data['total'] ) ); ?></p>
    </div>
    <?php

    $html = trim( (string) ob_get_clean() );
    return (string) preg_replace( '/>\s+</', '><', $html );
}

/**
 * Render the progressive load-more control.
 *
 * @param array<string,mixed> $data Prepared query data.
 * @return string
 */
function themisdb_v3_render_mixed_cards_pager( array $data ) {
    if ( empty( $data['has_more'] ) ) {
        return '';
    }

    $next_page = (int) $data['page'] + 1;
    $state     = $data['state'];
    $state['page'] = $next_page;

    return '<div class="tv3-card-loadmore-wrap" data-tv3-loadmore-wrap><span class="tv3-card-loadmore-hint">' . esc_html__( 'Weitere Inhalte werden automatisch geladen.', 'themisdb-v3' ) . '</span><a class="tv3-card-loadmore" href="' . esc_url( themisdb_v3_get_mixed_cards_url( $state ) ) . '" data-tv3-load-more="' . esc_attr( (string) $next_page ) . '">' . esc_html__( 'Jetzt laden', 'themisdb-v3' ) . '</a></div>';
}

/**
 * Render the full mixed-card section with AJAX controls.
 *
 * @param array<string,mixed> $data Prepared query data.
 * @return string
 */
function themisdb_v3_render_mixed_cards_section( array $data ) {
    wp_enqueue_script( 'themisdb-v3-mixed-cards' );

    $section_id = wp_unique_id( 'tv3-mixed-cards-' );
    $context_class = is_front_page() ? ' tv3-query-front' : '';

    ob_start();
    ?>
    <section id="<?php echo esc_attr( $section_id ); ?>" class="tv3-query tv3-query-mixed<?php echo esc_attr( $context_class ); ?>" data-tv3-mixed-cards data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-ajax-nonce="<?php echo esc_attr( wp_create_nonce( 'themisdb_v3_mixed_cards' ) ); ?>">
        <div class="tv3-card-controls-region" data-tv3-controls-region><?php echo themisdb_v3_render_mixed_cards_controls( $data ); ?></div>
        <div class="tv3-card-grid-region" data-tv3-grid-region><?php echo themisdb_v3_render_mixed_cards_grid( $data['posts'] ); ?></div>
        <div class="tv3-card-loadmore-region" data-tv3-pager-region><?php echo themisdb_v3_render_mixed_cards_pager( $data ); ?></div>
        <p class="tv3-card-feedback" data-tv3-feedback hidden></p>
    </section>
    <?php

    $html = trim( (string) ob_get_clean() );
    return (string) preg_replace( '/>\s+</', '><', $html );
}

/**
 * AJAX endpoint for mixed-card search, sorting and dynamic loading.
 */
function themisdb_v3_ajax_mixed_cards() {
    check_ajax_referer( 'themisdb_v3_mixed_cards', 'nonce' );

    $state = themisdb_v3_get_mixed_cards_state( array(), wp_unslash( $_POST ) );
    $data  = themisdb_v3_prepare_mixed_cards_data( $state );

    wp_send_json_success(
        array(
            'controlsHtml' => themisdb_v3_render_mixed_cards_controls( $data ),
            'gridHtml'     => themisdb_v3_render_mixed_cards_grid( $data['posts'] ),
            'pagerHtml'    => themisdb_v3_render_mixed_cards_pager( $data ),
            'message'      => sprintf( _n( '%d Inhalt geladen', '%d Inhalte geladen', (int) $data['total'], 'themisdb-v3' ), (int) $data['total'] ),
        )
    );
}
add_action( 'wp_ajax_themisdb_v3_mixed_cards', 'themisdb_v3_ajax_mixed_cards' );
add_action( 'wp_ajax_nopriv_themisdb_v3_mixed_cards', 'themisdb_v3_ajax_mixed_cards' );

/**
 * Render mixed content cards with search, sorting and progressive loading.
 *
 * @param array<string,mixed> $atts Shortcode attributes.
 * @return string
 */
function themisdb_v3_render_mixed_cards_shortcode( $atts ) {
    $atts  = shortcode_atts(
        array(
            'limit' => 12,
            'type'  => '',
        ),
        $atts,
        'themisdb_v3_mixed_cards'
    );
    $state = themisdb_v3_get_mixed_cards_state( $atts );
    $data  = themisdb_v3_prepare_mixed_cards_data( $state );

    return themisdb_v3_render_mixed_cards_section( $data );
}
add_shortcode( 'themisdb_v3_mixed_cards', 'themisdb_v3_render_mixed_cards_shortcode' );
